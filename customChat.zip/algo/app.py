from flask import Flask, render_template, request, Response, jsonify
from flask_bootstrap import Bootstrap
from dotenv import load_dotenv
from typing import List, Dict
from ollama import Client
import logging
import json

app = Flask(__name__)
Bootstrap(app)

logging.basicConfig(level=logging.DEBUG)
load_dotenv()  # This loads the variables from '.env'.

SELECTED_MODEL = "gemma2"

base_system_prompt = "Eres un asistente que habla español y da respuestas precisas y largas. Te gusta pensar en voz alta y comentar tus inquietudes"

system_prompt = base_system_prompt
current_prompt = None

@app.route('/')
def home():
    return render_template('chat.html')

@app.route('/start_chat', methods=['POST'])
def start_chat():
    global current_prompt
    data = request.json
    message = data['message']
    history = data['history']
    formatted_prompt = [{"role": "system", "content": system_prompt}]

    for entry in history[:-1]:
        formatted_prompt.append({"role": "user", "content": entry['user']})
        formatted_prompt.append({"role": "assistant", "content": entry['bot']})

    formatted_prompt.append({"role": "user", "content": message})
    current_prompt = formatted_prompt

    return jsonify({"status": "Chat iniciado"})

@app.route('/stream_chat', methods=['GET'])
def stream_chat():
    def generate():
        app.logger.debug("Iniciando streaming")
        client = Client()
        complete_answer = ""

        try:
            response = client.chat(
                model=SELECTED_MODEL,
                messages=current_prompt,
                options={
                    'temperature': 0.2,
                    'num_ctx': 8192
                },
                stream=True
            )

            for chunk in response:
                if 'content' in chunk['message']:
                    content = chunk['message']['content'].replace('\n', '\\n')
                    complete_answer += content
                    yield f"data: {content}\n\n"

            yield "data: [DONE]\n\n"

        except Exception as e:
            app.logger.error(f"Error durante el streaming: {str(e)}")
            yield f"data: Error: {str(e)}\n\n"

        app.logger.debug("Streaming finalizado")

    return Response(generate(), content_type='text/event-stream')

if __name__ == '__main__':
    app.run(debug=True, port=5000)