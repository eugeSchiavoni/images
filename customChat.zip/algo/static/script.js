$(document).ready(function () {
    var chatHistory = [];
    var converter = new showdown.Converter();

    function formatMessage(text) {
        // Reemplazar \n con saltos de línea reales antes del preprocesamiento
        text = text.replace(/\\n/g, '\n');

        // Preprocesamiento del Markdown
        text = preprocessMarkdown(text);

        // Usar marked para el procesamiento final del Markdown
        var markedOptions = {
            breaks: true,
            gfm: true
        };
        text = marked.parse(text, markedOptions);

        return text;
    }

    function preprocessMarkdown(content) {
        // Manejo de énfasis combinado (negrita y cursiva)
        content = content.replace(/\*\*\*(.*?)\*\*\*/g, '<strong><em>$1</em></strong>');
        // Manejo de negrita
        content = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        // Manejo de cursiva
        content = content.replace(/(?<!\*)\*(?!\*)([^*\n]+?)(?<!\*)\*(?!\*)/g, '<em>$1</em>');
        // Asegura que haya un espacio entre los # y el texto del título, para cualquier número de #
        content = content.replace(/(^|\n)(#+)([^ #])/g, '$1$2 $3');
        // Maneja los dos puntos correctamente en listas
        content = content.replace(/(^|\n)([*-+]\s*)([^:\n]+):(\s*)/g, '$1$2$3:$4');
        // Asegura que las listas tengan un espacio después del -, *, o +
        content = content.replace(/(^|\n)[*-+](?=[^\s])/g, '$& ');
        // Asegura dos saltos de línea entre bloques, excepto donde ya hay múltiples saltos de línea
        content = content.replace(/(?<!\n)\n(?!\n)/g, '\n\n');
        // Añade un salto de línea antes de los títulos si no lo tienen
        content = content.replace(/(\n|^)([^\n]+)\n(#+ )/g, '$1$2\n\n$3');
        // Maneja correctamente los saltos de línea después de listas
        content = content.replace(/(\n\s*[-*+]\s+[^\n]+)(\n\s+)/g, '$1\n$2');
        // Añade un salto de línea antes de elementos de lista si no lo tienen
        content = content.replace(/(\n|^)([^\n]+)\n([-*])/g, '$1$2\n\n$3');
        // Normaliza las tablas para asegurar saltos de línea antes y después y espacios correctos
        content = content.replace(/(\n|^)([^\n]*\|[^\n]*\n)([^\n]*\|-*\|[^\n]*\n(?:[^\n]*\|[^\n]*\n)*)/g, '\n$1$2$3\n');
        content = content.replace(/(\|)\s*([^|]+?)\s*(?=\|)/g, '$1 $2 ');
        return content;
    }

    function addMessage(message, isUser) {
        var messageClass = isUser ? 'user-message' : 'bot-message';
        var content = isUser ? message : formatMessage(message);
        $('#chat-box').append(
            '<div class="message ' + messageClass + '">' +
            '<span class="message-content">' + content + '</span>' +
            '</div>'
        );
        $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
    }

    $('#chat-form').submit(function (e) {
        e.preventDefault();
        var userMessage = $('#user-input').val();
        if (userMessage.trim() === '') return;
        addMessage(userMessage, true);
        chatHistory.push({ user: userMessage, bot: '' });

        $.ajax({
            url: '/start_chat',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ message: userMessage, history: chatHistory }),
            success: function () {
                var eventSource = new EventSource('/stream_chat');
                var botMessage = "";
                addMessage('', false);
                eventSource.onmessage = function (event) {
                    if (event.data === "[DONE]") {
                        chatHistory[chatHistory.length - 1].bot = botMessage.trim();
                        eventSource.close();
                    } else {
                        botMessage += event.data;
                        $('#chat-box .bot-message:last .message-content').html(formatMessage(botMessage));
                    }
                    $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
                };
                eventSource.onerror = function () {
                    eventSource.close();
                };
            }
        });

        $('#user-input').val('');
    });
});